const express = require('express');
const controller = require('../controllers/cmd_controller');

const router = express.Router();

router.get('/health', controller.health);
router.post('/cmd', controller.handleCommand);
router.get('/state', controller.getState);
router.post('/parse', controller.resolveIntent)

module.exports = router;
