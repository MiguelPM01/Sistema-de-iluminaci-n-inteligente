const osc = require('osc');
const { QLC_HOST, QLC_PORT } = require('../config/env');

const sendCommand = async (command) => {
    if (!command) {
        return {
            ok: false,
            error: 'command is required'
        };
    }

    //console.log(`sendCommand started`, command);


    return new Promise((resolve) => {
        const udpPort = new osc.UDPPort({
            localAddress: '0.0.0.0',
            localPort: 0,
            remoteAddress: QLC_HOST,
            remotePort: QLC_PORT,
            metadata: true
        });

        udpPort.on('ready', () => {
            //console.log('UDP ready:', command);
            udpPort.send({
                address: command,
                args: [{ type: 'i', value: 1 }]
            });

            setTimeout(() => {
                //console.log('Sending OFF pulse:', command);
                udpPort.send({
                    address: command,
                    args: [{ type: 'i', value: 0 }]
                });

                console.log(`OSC pulse sent: ${command}`);

                udpPort.close();

                //console.log('Resolving success:', command);

                resolve({
                    ok: true,
                    sent: command
                });
            }, 120);
        });

        udpPort.on('error', (error) => {
            //console.log('Resolving error:', command);
            console.error('OSC error:', error);

            try {
                udpPort.close();
            } catch (_) {}

            resolve({
                ok: false,
                error: 'failed to send osc command'
            });
        });

        udpPort.open();
    });

};

module.exports = { sendCommand };