const qlcService = require('./qlc_service');
const SENSITIVE_INTENTS = ['BLACKOUT'];
let pendingIntent = null;
let pendingTimestamp = null;

const CONFIRMATION_WORDS = ['sí', 'si', 'ok', 'confirmo'];
const  CONFIRMATION_TIMEOUT_MS = 15000;
const CANCEL_WORDS = ['no', 'cancelar', 'cancela'];

const VALID_INTENTS = ['RED',
     'BLUE',
     'GREEN',
     'WHITE',
     'BLACKOUT',
     'SHOW',
     'CYAN',
     'PARTY',
     'MAGENTA',
     'ORANGE',
     'WARM',
    'YELLOW'];

     
 const TEXT_MAP = {
    RED: ['rojo', 'roja', 'luz roja', 'pon rojo'],
    BLUE: ['azul', 'luz azul', 'pon azul'],
    GREEN: ['verde', 'luz verde', 'pon verde'],
    WHITE: ['blanco', 'blanca', 'luz blanca', 'pon blanca', 'pon blanco'],
    SHOW: ['modo f1', 'activa modo f uno', 'show F uno', 'modo f uno'],
    BLACKOUT: ['apaga', 'apagar', 'blackout'],
    PARTY: ['modo fiesta', 'fiesta', 'party'],
    CYAN:['cyan', 'cian', 'luz cian', 'luz cyan', 'pon cian', 'pon cyan'],
    MAGENTA: ['magenta', 'pon magenta', 'luz magenta'],
    ORANGE: ['naranja', 'pon naranja', 'luz naranja'],
    WARM: ['modo presentar', 'presentar', 'activa modo presentar'],
    YELLOW: ['amarillo', 'amarilla', 'luz amarilla', 'pon amarilla'],

    };

    const executeCommand =  async ({ intent, text, confirmed }) => {
    const normalizedText = text ? text.trim().toLowerCase() : '';

    if (CANCEL_WORDS.includes(normalizedText) && pendingIntent) {
    pendingIntent = null;
    pendingTimestamp = null;

    return {
        ok: true,
        cancelled: true,
        message: 'Acción cancelada'
        };
    }

    if (CONFIRMATION_WORDS.includes(normalizedText) && pendingIntent) {
    const isExpired = Date.now() - pendingTimestamp > CONFIRMATION_TIMEOUT_MS;

    if (isExpired) {
        pendingIntent = null;
        pendingTimestamp = null;

        return {
            ok: false,
            error: 'La confirmación expiró'
        };
    }

    const intentToExecute = pendingIntent;
    pendingIntent = null;
    pendingTimestamp = null;

    return await qlcService.executeMode(intentToExecute);
}

const result = resolveIntent({ intent, text });

    if (!result.ok) {
    return result;
    }

   if (SENSITIVE_INTENTS.includes(result.intent) && confirmed !== true) {
    pendingIntent = result.intent;
    pendingTimestamp = Date.now();

    return {
        ok: true,
        needsConfirmation: true,
        intent: result.intent,
        message: '¿Seguro que quieres apagar todo?'
         };
    } 
    return await qlcService.executeMode(result.intent);
}

const resolveIntent = ({ intent, text }) => {
    let resolvedIntent = intent ? intent.trim().toUpperCase() : '';
    const normalizedText = text ? text.trim().toLowerCase() : '';

    if (!resolvedIntent && !normalizedText) {
        return {
            ok: false,
            error: 'intent or text is required'
        };
    }

    if (!resolvedIntent) {
        for (const key in TEXT_MAP) {
            const aliases = TEXT_MAP[key];
            const matchFound = aliases.some(alias => normalizedText.includes(alias));

            if (matchFound) {   
                resolvedIntent = key;
                break;
            }
        }
    }

    if (!VALID_INTENTS.includes(resolvedIntent)) {
        return {
            ok: false,
            error: 'invalid intent'
        };
    }

    return {
        ok: true,
        intent: resolvedIntent
    };
};

module.exports = { executeCommand, resolveIntent }; 

