const oscService = require('./osc_service');

let lastExecutionTime = 0;
const COOLDOWN_MS = 300;

const MODE_MAP = {
    RED: 'Activando rojo',
    GREEN: 'Activando verde',
    BLUE: 'Activando azul',
    WHITE: 'Activando blanco',
    SHOW: 'Activando modo F1',
    PARTY: 'Activando modo fiesta',
    CYAN: 'Activando cyan',
    MAGENTA: 'Activando magenta',
    ORANGE: 'Activando naranja',
    BLACKOUT: 'Apagando...',
    WARM: 'Activando modo presentar',
    YELLOW: 'Activando amarillo',
};

const MODE_TO_COMMAND = {
    RED: '/cmd/1',
    BLUE: '/cmd/2',
    GREEN: '/cmd/3',
    WHITE: '/cmd/4',
    SHOW: '/cmd/5',
    BLACKOUT: '/cmd/6',
    PARTY: '/cmd/7',
    CYAN: '/cmd/8',
    MAGENTA: '/cmd/9',
    ORANGE: '/cmd/10',
    WARM: '/cmd/11',
    YELLOW: '/cmd/12'
};

let activeMode = null;

const executeMode = async (mode) => {
    const now = Date.now();

    if (now - lastExecutionTime < COOLDOWN_MS) {
        return {
            ok: true,
            message: 'Command ignored (cooldown)',
            skipped: true
        };
    }

    if (activeMode === mode) {
        return {
            ok: true,
            message: `${mode} ya está activo`,
            executed: mode,
            skipped: true
        };
    }

    const command = MODE_TO_COMMAND[mode];
    const message = MODE_MAP[mode];
    const previousMode = activeMode;

    if (!command || !message) {
        return {
            ok: false,
            error: 'unsupported mode'
        };
    }

    if (previousMode && previousMode !== mode) {
        const previousCommand = MODE_TO_COMMAND[previousMode];
        const turnOffResult = await oscService.sendCommand(previousCommand);

        if (!turnOffResult.ok) {
            return {
                ok: false,
                error: `failed to turn off previous mode: ${previousMode}`
            };
        }
    }

    const sendResult = await oscService.sendCommand(command);

    if (!sendResult.ok) {
        return sendResult;
    }

    activeMode = mode;
    lastExecutionTime = now;

    return {
        ok: true,
        executed: mode,
        message,
        command,
        sent: sendResult.sent,
        previousMode
    };
};

const getState = () => {
    return {
        ok: true,
        activeMode
    };
};

module.exports = { executeMode, getState };