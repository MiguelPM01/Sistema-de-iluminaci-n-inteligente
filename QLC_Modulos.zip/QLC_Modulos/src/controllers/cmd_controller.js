const commandService = require('../services/command_service');
const qlcService = require('../services/qlc_service');

const health = (req, res) => {
    res.json({ok: true, message: "API running"});
}

const handleCommand = async (req, res) => {
    try {
        const { intent, text, confirmed } = req.body;
        const result = await commandService.executeCommand({ intent, text, confirmed });
        res.status(result.ok ? 200 : 400).json(result);
    } catch (error) {
        console.error('handleCommand error:', error);

        res.status(500).json({
            ok: false,
            error: 'internal server error'
        });
    }
};

const getState = (req, res) => {
    const result = qlcService.getState();
    res.json(result);
}

const resolveIntent = (req, res) => {
    const { intent, text } = req.body;
    const result = commandService.resolveIntent({ intent, text });
    res.json(result);
};


module.exports = { health, handleCommand, getState, resolveIntent };
