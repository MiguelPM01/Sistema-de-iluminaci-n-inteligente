const express = require('express');
const cmdRoutes = require('./routes/cmd_routes');

const app = express();

app.use(express.json());
app.use("/", cmdRoutes);

module.exports = app;

