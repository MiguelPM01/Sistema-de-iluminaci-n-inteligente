const PORT = process.env.PORT || 3000;
const QLC_HOST = process.env.QLC_HOST || '127.0.0.1';
const QLC_PORT = Number(process.env.QLC_PORT || 7700);

module.exports = {
    PORT,
    QLC_HOST,
    QLC_PORT
};
